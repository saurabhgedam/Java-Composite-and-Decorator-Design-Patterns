
/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
public class Cheese extends Decorator
{
    // instance variables - replace the example below with your own
    
    private Decorator decorator;
    private String[] cheese = new String[25];

    public Cheese(Decorator decorator,String[] cheese)
    {
        this.cheese = cheese;
       this.decorator= decorator;       
    }
       /**
     * Constructor for objects of class Cheese
     */
    public void printDescription(){
        String desc="";
       decorator.printDescription();
        for (int i=0;i<cheese.length;i++){
            desc =desc + cheese[i];
            if(i!=cheese.length-1)
            {
                desc = desc + " + ";
            }  
        }
        System.out.println(""+desc);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double cost(){
        if(cheese.length>1){
            return (1*(cheese.length-1))+decorator.cost();
        }
         else
            return 0+ decorator.cost();
    }
}