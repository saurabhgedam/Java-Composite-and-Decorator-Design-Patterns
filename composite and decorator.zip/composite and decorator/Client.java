 /**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */

public class Client {

    public static void runTest()
    {
        Component theOrder = BuildOrder.getOrder() ;
        theOrder.printDescription();

    }
}
 
