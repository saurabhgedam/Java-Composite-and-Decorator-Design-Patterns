/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
import java.text.DecimalFormat;
public class CustomBurger extends Composite
{
    // instance variables - replace the example below with your own
    public Decorator dcustburg;
    public String description ;
    public double price ;
   

    /**
     * Constructor for objects of class CustomBurger
     */
    public CustomBurger(Decorator dcustburg)
    {
     this.dcustburg = dcustburg;
        price = dcustburg.cost() ;
      description = "Build Your Own Burger";
        // initialise instance variables   
    }
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void printDescription() {
    DecimalFormat fmt = new DecimalFormat("0.00");
        System.out.println( description + " " + fmt.format(price) ) ;
      this.dcustburg.printDescription();
    }
}
