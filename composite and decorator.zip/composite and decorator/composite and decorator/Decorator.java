/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
public abstract class Decorator extends Leaf implements PDecorator
{
  
    public double price;
    public String description= "";
    public void printDescription()
    {
        System.out.println(""+description );
    }
}