/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
public class Premium extends Decorator
{
    // instance variables - replace the example below with your own
   
   private Decorator decorator;
    
    /**
     * Constructor for objects of class Premium
     */
    String[] ptoppings = new String[25];
    public Premium(Decorator decorator,String[] ptoppings)
    {
        // initialise instance variables
        this.ptoppings=ptoppings;
       this.decorator=decorator;      
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sampprele parameter for a method
     * @return     the sum of x and y 
     */
   public void printDescription(){
        String desc="";
         decorator.printDescription();
        for(int i=0;i<ptoppings.length;i++)
        {
            desc=desc + ptoppings[i];
            if(i!=ptoppings.length-1)
            desc=desc+" + ";
        }
        System.out.println(""+desc);
    }
     public double cost(){
  if(ptoppings.length>0)
        {
         return (1.50*ptoppings.length)+decorator.cost();
        }
        else
         return decorator.cost()+0;
    }
}