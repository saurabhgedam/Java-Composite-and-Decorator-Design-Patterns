
/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
public class Sauce extends Decorator
{
    // instance variables - replace the example below with your own
    private Decorator decorator;
    private String[] sauce = new String[25];
    /**
     * Constructor for objects of class Sauce
     */
    public Sauce(Decorator decorator,String[] sauce)
    
    {
        this.decorator= decorator;
       this.sauce = sauce;
        // initialise instance variables
    }
    public void printDescription(){
        String desc= "";        
        decorator.printDescription();
        for (int i=0;i<sauce.length;i++){
            desc =desc + sauce[i];
            if(i!=sauce.length-1)
            {
                desc = desc + " + ";
            }            
        }
        System.out.println(""+desc);
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */   
     public double cost(){
        if(sauce.length>1){
            return (1*(sauce.length-1))+decorator.cost();
        }
         else
            return decorator.cost()+0;
    }
}