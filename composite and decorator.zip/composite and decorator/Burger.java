/**
 * Write a description of class Cheese here.
 * 
 * @author Saurabh Gedam
 * @version (a version number or a date)
 */
public class Burger extends Decorator
{
    // instance variables - replace the example below with your own
    /**
     * Constructor for objects of class Burger
     */
    private String serve="";
 private String type ="";
    private String size ="";
    
 public Burger (String type,String size,String serve){
        this.type=type;
        this.size=size;
        this.serve=serve;
        description = type + " + "+ size + " + " + serve;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double cost(){
            double cost=0;
        if(size=="1/3lb.")
        {
            cost= 9.50;
        }
        else if(size=="2/3lb.")       
       {
            cost=11.50;
        }
        else if(size=="1lb.")       
         {
            cost= 15.50;
        }
        
       if(serve=="In a Bowl")
         {
            cost=cost+1;
        }
        
        return cost;
    }
}